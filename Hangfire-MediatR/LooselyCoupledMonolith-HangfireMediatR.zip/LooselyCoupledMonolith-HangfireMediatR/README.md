# Loosely Coupled Monolith

All the source code for my Loosely Coupled Monolith series of videos on YouTube.

CodeOpinion YouTube Channel:
https://www.youtube.com/channel/UC3RKA4vunFAfrfxiJhPEplw/
